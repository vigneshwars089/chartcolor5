function viewchart1() {
  mycolor=["black"];     //to null the color properties for new chart
  colorflag=0;
    $('#DrawChart').empty();
    // console.log("enter");
    // to load dropdown value
    $('#2dim_dropdown1').empty();
    // debugger;
    var select = document.getElementById("2dim_dropdown1");
    var options = headArray;
    for (var i = 0; i < options.length; i++) {
        var opt = options[i];
        var el = document.createElement("option");
        el.textContent = opt;
        el.value = opt;
        select.appendChild(el);
    }
    $('#2dim_dropdown2').empty();

    var select = document.getElementById("2dim_dropdown2");
    var options = headArray;
    for (var i = 0; i < options.length; i++) {
        var opt = options[i];
        var el = document.createElement("option");
        el.textContent = opt;
        el.value = opt;
        select.appendChild(el);
    }

    var radioBtn = $('<a class="active" href="javascript:;" onclick="drawchart(this)" title="Pie Chart">Pie Chart</a><a class="inactive" onclick="drawchart(this)" href="javascript:;" title="Column Chart">Column Chart</a><a class="inactive" onclick="drawchart(this)" href="javascript:;" title="Donut Chart">Donut Chart</a>');
    $('#Chart_div').empty().append(radioBtn);
};
function viewchart2() {
  mycolor=["black"];
  colorflag=0;
    $('#DrawChart').empty();
    $('#X2Y1').empty();

    var select = document.getElementById("X2Y1");
    var options = headArray;
    for (var i = 0; i < options.length; i++) {
        var opt = options[i];
        var el = document.createElement("option");
        el.textContent = opt;
        el.value = opt;
        select.appendChild(el);
    }

    $('#X2YN').empty();
    var list = document.getElementById("X2YN");
    var li = 0;
    var link = 0;
    for (var i = 0; i < headArray.length; i++) {
        var opt = headArray[i];
        console.log(headArray.length);
        li = document.createElement("li");
        link = document.createElement("a");
        link.href = "#";
        link.class = "small";

        var check = document.createElement("input");
        check.type = "checkbox";
        var text = document.createTextNode(opt);
        link.appendChild(text);
        var color = document.createElement("input");
        color.className="colorpickers";
        color.id=opt;
      // var colText='"'+'#'+opt+'"';
      // console.log(colText.toString());
      // var par=colText.toString();

        //  link.data-value = opt;

        link.appendChild(check);
        li.appendChild(link);
        li.appendChild(color);
        list.appendChild(li);
    }
    $(".colorpickers").spectrum({
            color: "#f00"
        });
    var radioBtn = $('<a class="active" href="javascript:;" onclick="drawchart(this)" title="Stacked chart">Stacked chart</a><a class="inactive" onclick="drawchart(this)" href="javascript:;" title="Area chart">Area chart</a><a class="inactive" onclick="drawchart(this)" href="javascript:;" title="Line Chart">Line Chart</a>');
    $('#Chart_div').empty().append(radioBtn);
};
function viewchart4() {
  mycolor=["black"];
  colorflag=0;
    $('#DrawChart').empty();
    $('#3dim1').empty();

    var select = document.getElementById("3dim1");
    var options = headArray;
    for (var i = 0; i < options.length; i++) {
        var opt = options[i];
        var el = document.createElement("option");
        el.textContent = opt;
        el.value = opt;
        select.appendChild(el);
    }

    $('#3dim2').empty();

    var select = document.getElementById("3dim2");
    var options = headArray;
    for (var i = 0; i < options.length; i++) {
        var opt = options[i];
        var el = document.createElement("option");
        el.textContent = opt;
        el.value = opt;
        select.appendChild(el);
    }
    $('#3dim3').empty();

    var select = document.getElementById("3dim3");
    var options = headArray;
    for (var i = 0; i < options.length; i++) {
        var opt = options[i];
        var el = document.createElement("option");
        el.textContent = opt;
        el.value = opt;
        select.appendChild(el);
    }


    var radioBtn = $('<a class="active" href="javascript:;" onclick="drawchart(this)" title="Scatter chart">Scatter chart</a>');
    $('#Chart_div').empty().append(radioBtn);
};
function viewchart5() {
  mycolor=["black"];
  colorflag=0;
    $('#DrawChart').empty();
    $('#combination1').empty();

    var select = document.getElementById("combination1");
    var options = headArray;
    for (var i = 0; i < options.length; i++) {
        var opt = options[i];
        var el = document.createElement("option");
        el.textContent = opt;
        el.value = opt;
        select.appendChild(el);
    }
    $('#combination2').empty();

    var select = document.getElementById("combination2");
    var options = headArray;
    for (var i = 0; i < options.length; i++) {
        var opt = options[i];
        var el = document.createElement("option");
        el.textContent = opt;
        el.value = opt;
        select.appendChild(el);
    }
    $('#combination3').empty();
    var list = document.getElementById("combination3");
    var li = 0;
    var link = 0;
    for (var i = 0; i < headArray.length; i++) {
        var opt = headArray[i];
        console.log(headArray.length);
        li = document.createElement("li");
        link = document.createElement("a");
        link.href = "#";
        link.class = "small";

        var check = document.createElement("input");
        check.type = "checkbox";
        var text = document.createTextNode(opt);
        link.appendChild(text);
        var color = document.createElement("input");
        color.className="colorpickers";
        color.id=opt;
        //  link.data-value = opt;

        link.appendChild(check);
        li.appendChild(link);
        li.appendChild(color);
        list.appendChild(li);
    }
    $(".colorpickers").spectrum({
            color: "#f00"
        });

    var radioBtn = $('<a class="active" href="javascript:;" onclick="drawchart(this)" title="Line-Bar chart">Line-Bar chart</a><a class="inactive" onclick="drawchart(this)" href="javascript:;" title="Bar-Line chart">Bar-Line chart</a><a class="inactive" onclick="drawchart(this)" href="javascript:;" title="Area-Bar chart">Area-Bar chart</a><a class="inactive" onclick="drawchart(this)" href="javascript:;" title="Bar-Area chart">Bar-Area chart</a><a class="inactive" onclick="drawchart(this)" href="javascript:;" title="Area-Line chart">Area-Line chart</a><a class="inactive" onclick="drawchart(this)" href="javascript:;" title="Line-Area chart">Line-Area chart</a>');
    $('#Chart_div').empty().append(radioBtn);
};

var dropdownvalue;


var ChartName;
function drawchart(btntype) {


    ChartName = $(btntype).attr('title');
    $('a.active ').removeClass('active').addClass('inactive');
    $(btntype).addClass('active');


    if (ChartName == "Line-Bar chart") {

        var ChartTitle = document.getElementById("title3").value;
        var e = document.getElementById("combination1");
        var strUser = e.options[e.selectedIndex].text;
        var YAxisSelectedItem = '';
        var flag = true;
        $('#combination3 li').each(function () {

          var selectedstring = $(this).next('li').find('input').prop('checked');
          if (selectedstring) {
              if (flag) {
                  var newY = $(this).next('li')[0].innerText;
                // if (!newY.substring(-1).match(/[_\W]/))
                // {
                //   console.log("workin");
                // }
                //   if(newY.indexOf(/[@]+$/) != -1)
                //   {
                //     console.log("run");
                //   }
                var last=newY.charAt(newY.length-2);
                console.log(last);

                var match = /\r|\n/.exec(last);
                if (match) {
                  YAxisSelectedItem=newY.substring(0,newY.length-2);
                }
                else {
                  YAxisSelectedItem=newY.substring(0,newY.length-1);
                }
                // if( /[^a-zA-Z0-9]/.test( TCode ) ) {
                //   alert('Input is not alphanumeric');
                //   return false;
                // }
                  // var colorID=YAxisSelectedItem.substring(0, YAxisSelectedItem.length-1);
                  // console.log(document.getElementById(colorID).value);
                  console.log(YAxisSelectedItem);
                  var c = Color(document.getElementById(YAxisSelectedItem).value);
                  color_Array=[c.toString()];
                  flag = false;
                  console.log(c);
              }
              else {
                  var newY=$(this).next('li')[0].innerText;
                  var last=newY.charAt(newY.length-2);
                  console.log(last);
                  // if (last=='') {
                  // }
                  var match = /\r|\n/.exec(last);
                  if (match) {
                    var newY2=newY.substring(0,newY.length-2);
                  }
                  else {
                    var newY2=newY.substring(0,newY.length-1);
                  }
                  // var newY2=newY.substring(0,newY.length-2);
                  console.log(newY2);
                  YAxisSelectedItem = YAxisSelectedItem+","+newY2;
                  // console.log(YAxisSelectedItem);
                  var c = Color(document.getElementById(newY2).value);
                  color_Array.push(c.toString());
                  console.log(YAxisSelectedItem);
              }
          }

        });

        var x = headArray.indexOf(strUser);
        var Zaxis = document.getElementById("combination2");
        var ZaxisValue = Zaxis.options[Zaxis.selectedIndex].text;
        var zindex = headArray.indexOf(ZaxisValue);

        var filterdata = [];
        var tempdata = [];

        var Reportcollen = 0;
        for (var i = 0; i < mystack.length; i++) {

            var column = [];

            column.push(mystack[i][x]);
            var str_array = YAxisSelectedItem.split(',');

            for (var iarr = 0; iarr < str_array.length; iarr++) {
                var y = headArray.indexOf(str_array[iarr]);
                column.push(mystack[i][y]);
            }
            column.push(mystack[i][zindex]);
            filterdata.push(column);
        }
        Reportcollen += str_array.length;

        BindChart(ChartName, ChartTitle, filterdata, Reportcollen,color_Array);

    }

    if (ChartName == "Bar-Line chart") {



        var ChartTitle = document.getElementById("title3").value;

        var e = document.getElementById("combination1");
        var strUser = e.options[e.selectedIndex].text;
        var YAxisSelectedItem = '';
        var flag = true;
        $('#combination3 li').each(function () {
            // debugger;
            var selectedstring = $(this).next('li').find('input').prop('checked');
            if (selectedstring) {
                if (flag) {
                    var newY = $(this).next('li')[0].innerText;
                  // if (!newY.substring(-1).match(/[_\W]/))
                  // {
                  //   console.log("workin");
                  // }
                  //   if(newY.indexOf(/[@]+$/) != -1)
                  //   {
                  //     console.log("run");
                  //   }
                  var last=newY.charAt(newY.length-2);
                  console.log(last);
                  // if (last=='') {
                  // }
                  var match = /\r|\n/.exec(last);
                  if (match) {
                    YAxisSelectedItem=newY.substring(0,newY.length-2);
                  }
                  else {
                    YAxisSelectedItem=newY.substring(0,newY.length-1);
                  }
                  // if( /[^a-zA-Z0-9]/.test( TCode ) ) {
                  //   alert('Input is not alphanumeric');
                  //   return false;
                  // }
                    // var colorID=YAxisSelectedItem.substring(0, YAxisSelectedItem.length-1);
                    // console.log(document.getElementById(colorID).value);
                    console.log(YAxisSelectedItem);
                    var c = Color(document.getElementById(YAxisSelectedItem).value);
                    color_Array=[c.toString()];
                    flag = false;
                    console.log(c);
                }
                else {
                    var newY=$(this).next('li')[0].innerText;
                    var last=newY.charAt(newY.length-2);
                    console.log(last);
                    // if (last=='') {
                    // }
                    var match = /\r|\n/.exec(last);
                    if (match) {
                      var newY2=newY.substring(0,newY.length-2);
                    }
                    else {
                      var newY2=newY.substring(0,newY.length-1);
                    }
                    // var newY2=newY.substring(0,newY.length-2);
                    console.log(newY2);
                    YAxisSelectedItem = YAxisSelectedItem+","+newY2;
                    // console.log(YAxisSelectedItem);
                    var c = Color(document.getElementById(newY2).value);
                    color_Array.push(c.toString());
                    console.log(YAxisSelectedItem);
                }
            }

        });


        var x = headArray.indexOf(strUser);
        var Zaxis = document.getElementById("combination2");
        var ZaxisValue = Zaxis.options[Zaxis.selectedIndex].text;
        var zindex = headArray.indexOf(ZaxisValue);

        var filterdata = [];
        var tempdata = [];
        //console.log(x);
        // debugger;
        var Reportcollen = 0;
        for (var i = 0; i < mystack.length; i++) {
            // debugger;
            var column = [];
            // console.log(mystack);
            column.push(mystack[i][x]);
            var str_array = YAxisSelectedItem.split(',');

            for (var iarr = 0; iarr < str_array.length; iarr++) {
                var y = headArray.indexOf(str_array[iarr]);
                column.push(mystack[i][y]);


            }
            column.push(mystack[i][zindex]);
            filterdata.push(column);
        }

        Reportcollen += str_array.length;

        BindChart(ChartName, ChartTitle, filterdata, Reportcollen,color_Array);
    }

    if (ChartName == "Area-Bar chart") {

        var ChartTitle = document.getElementById("title3").value;

        var e = document.getElementById("combination1");
        var strUser = e.options[e.selectedIndex].text;
        var YAxisSelectedItem = '';
        var flag = true;
        $('#combination3 li').each(function () {
            // debugger;
            var selectedstring = $(this).next('li').find('input').prop('checked');
            if (selectedstring) {
                if (flag) {
                    var newY = $(this).next('li')[0].innerText;
                  // if (!newY.substring(-1).match(/[_\W]/))
                  // {
                  //   console.log("workin");
                  // }
                  //   if(newY.indexOf(/[@]+$/) != -1)
                  //   {
                  //     console.log("run");
                  //   }
                  var last=newY.charAt(newY.length-2);
                  console.log(last);
                  // if (last=='') {
                  // }
                  var match = /\r|\n/.exec(last);
                  if (match) {
                    YAxisSelectedItem=newY.substring(0,newY.length-2);
                  }
                  else {
                    YAxisSelectedItem=newY.substring(0,newY.length-1);
                  }
                  // if( /[^a-zA-Z0-9]/.test( TCode ) ) {
                  //   alert('Input is not alphanumeric');
                  //   return false;
                  // }
                    // var colorID=YAxisSelectedItem.substring(0, YAxisSelectedItem.length-1);
                    // console.log(document.getElementById(colorID).value);
                    console.log(YAxisSelectedItem);
                    var c = Color(document.getElementById(YAxisSelectedItem).value);
                    color_Array=[c.toString()];
                    flag = false;
                    console.log(c);
                }
                else {
                    var newY=$(this).next('li')[0].innerText;
                    var last=newY.charAt(newY.length-2);
                    console.log(last);
                    // if (last=='') {
                    // }
                    var match = /\r|\n/.exec(last);
                    if (match) {
                      var newY2=newY.substring(0,newY.length-2);
                    }
                    else {
                      var newY2=newY.substring(0,newY.length-1);
                    }
                    // var newY2=newY.substring(0,newY.length-2);
                    console.log(newY2);
                    YAxisSelectedItem = YAxisSelectedItem+","+newY2;
                    // console.log(YAxisSelectedItem);
                    var c = Color(document.getElementById(newY2).value);
                    color_Array.push(c.toString());
                    console.log(YAxisSelectedItem);
                }
            }

        });


        var x = headArray.indexOf(strUser);
        var Zaxis = document.getElementById("combination2");
        var ZaxisValue = Zaxis.options[Zaxis.selectedIndex].text;
        var zindex = headArray.indexOf(ZaxisValue);

        var filterdata = [];
        var tempdata = [];

        var Reportcollen = 0;
        for (var i = 0; i < mystack.length; i++) {

            var column = [];

            column.push(mystack[i][x]);
            var str_array = YAxisSelectedItem.split(',');

            for (var iarr = 0; iarr < str_array.length; iarr++) {
                var y = headArray.indexOf(str_array[iarr]);
                column.push(mystack[i][y]);


            }
            column.push(mystack[i][zindex]);
            filterdata.push(column);
        }

        Reportcollen += str_array.length;
        BindChart(ChartName, ChartTitle, filterdata, Reportcollen,color_Array);
    }

    if (ChartName == "Bar-Area chart") {

        var ChartTitle = document.getElementById("title3").value;
        var e = document.getElementById("combination1");
        var strUser = e.options[e.selectedIndex].text;
        var YAxisSelectedItem = '';
        var flag = true;
        $('#combination3 li').each(function () {

          var selectedstring = $(this).next('li').find('input').prop('checked');
          if (selectedstring) {
              if (flag) {
                  var newY = $(this).next('li')[0].innerText;
                // if (!newY.substring(-1).match(/[_\W]/))
                // {
                //   console.log("workin");
                // }
                //   if(newY.indexOf(/[@]+$/) != -1)
                //   {
                //     console.log("run");
                //   }
                var last=newY.charAt(newY.length-2);
                console.log(last);
                // if (last=='') {
                // }
                var match = /\r|\n/.exec(last);
                if (match) {
                  YAxisSelectedItem=newY.substring(0,newY.length-2);
                }
                else {
                  YAxisSelectedItem=newY.substring(0,newY.length-1);
                }
                // if( /[^a-zA-Z0-9]/.test( TCode ) ) {
                //   alert('Input is not alphanumeric');
                //   return false;
                // }
                  // var colorID=YAxisSelectedItem.substring(0, YAxisSelectedItem.length-1);
                  // console.log(document.getElementById(colorID).value);
                  console.log(YAxisSelectedItem);
                  var c = Color(document.getElementById(YAxisSelectedItem).value);
                  color_Array=[c.toString()];
                  flag = false;
                  console.log(c);
              }
              else {
                  var newY=$(this).next('li')[0].innerText;
                  var last=newY.charAt(newY.length-2);
                  console.log(last);
                  // if (last=='') {
                  // }
                  var match = /\r|\n/.exec(last);
                  if (match) {
                    var newY2=newY.substring(0,newY.length-2);
                  }
                  else {
                    var newY2=newY.substring(0,newY.length-1);
                  }
                  // var newY2=newY.substring(0,newY.length-2);
                  console.log(newY2);
                  YAxisSelectedItem = YAxisSelectedItem+","+newY2;
                  // console.log(YAxisSelectedItem);
                  var c = Color(document.getElementById(newY2).value);
                  color_Array.push(c.toString());
                  console.log(YAxisSelectedItem);
              }
          }

        });


        var x = headArray.indexOf(strUser);
        var Zaxis = document.getElementById("combination2");
        var ZaxisValue = Zaxis.options[Zaxis.selectedIndex].text;
        var zindex = headArray.indexOf(ZaxisValue);

        var filterdata = [];
        var tempdata = [];

        var Reportcollen = 0;
        for (var i = 0; i < mystack.length; i++) {

            var column = [];

            column.push(mystack[i][x]);
            var str_array = YAxisSelectedItem.split(',');

            for (var iarr = 0; iarr < str_array.length; iarr++) {
                var y = headArray.indexOf(str_array[iarr]);
                column.push(mystack[i][y]);


            }
            column.push(mystack[i][zindex]);
            filterdata.push(column);
        }

        Reportcollen += str_array.length;

        BindChart(ChartName, ChartTitle, filterdata, Reportcollen,color_Array);

    }


    if (ChartName == "Area-Line chart") {

        var ChartTitle = document.getElementById("title3").value;

        var e = document.getElementById("combination1");
        var strUser = e.options[e.selectedIndex].text;
        var YAxisSelectedItem = '';
        var flag = true;
        $('#combination3 li').each(function () {
            // debugger;
            var selectedstring = $(this).next('li').find('input').prop('checked');
            if (selectedstring) {
                if (flag) {
                    var newY = $(this).next('li')[0].innerText;
                  // if (!newY.substring(-1).match(/[_\W]/))
                  // {
                  //   console.log("workin");
                  // }
                  //   if(newY.indexOf(/[@]+$/) != -1)
                  //   {
                  //     console.log("run");
                  //   }
                  var last=newY.charAt(newY.length-2);
                  console.log(last);
                  // if (last=='') {
                  // }
                  var match = /\r|\n/.exec(last);
                  if (match) {
                    YAxisSelectedItem=newY.substring(0,newY.length-2);
                  }
                  else {
                    YAxisSelectedItem=newY.substring(0,newY.length-1);
                  }
                  // if( /[^a-zA-Z0-9]/.test( TCode ) ) {
                  //   alert('Input is not alphanumeric');
                  //   return false;
                  // }
                    // var colorID=YAxisSelectedItem.substring(0, YAxisSelectedItem.length-1);
                    // console.log(document.getElementById(colorID).value);
                    console.log(YAxisSelectedItem);
                    var c = Color(document.getElementById(YAxisSelectedItem).value);
                    color_Array=[c.toString()];
                    flag = false;
                    console.log(c);
                }
                else {
                    var newY=$(this).next('li')[0].innerText;
                    var last=newY.charAt(newY.length-2);
                    console.log(last);
                    // if (last=='') {
                    // }
                    var match = /\r|\n/.exec(last);
                    if (match) {
                      var newY2=newY.substring(0,newY.length-2);
                    }
                    else {
                      var newY2=newY.substring(0,newY.length-1);
                    }
                    // var newY2=newY.substring(0,newY.length-2);
                    console.log(newY2);
                    YAxisSelectedItem = YAxisSelectedItem+","+newY2;
                    // console.log(YAxisSelectedItem);
                    var c = Color(document.getElementById(newY2).value);
                    color_Array.push(c.toString());
                    console.log(YAxisSelectedItem);
                }
            }

        });


        var x = headArray.indexOf(strUser);
        var Zaxis = document.getElementById("combination2");
        var ZaxisValue = Zaxis.options[Zaxis.selectedIndex].text;
        var zindex = headArray.indexOf(ZaxisValue);

        var filterdata = [];
        var tempdata = [];
        //console.log(x);
        // debugger;
        var Reportcollen = 0;
        for (var i = 0; i < mystack.length; i++) {
            // debugger;
            var column = [];
            // console.log(mystack);
            column.push(mystack[i][x]);
            var str_array = YAxisSelectedItem.split(',');

            for (var iarr = 0; iarr < str_array.length; iarr++) {
                var y = headArray.indexOf(str_array[iarr]);
                column.push(mystack[i][y]);


            }
            column.push(mystack[i][zindex]);
            filterdata.push(column);
        }

        Reportcollen += str_array.length;

        BindChart(ChartName, ChartTitle, filterdata, Reportcollen,color_Array);

    }


    if (ChartName == "Line-Area chart") {

        var ChartTitle = document.getElementById("title3").value;
        var e = document.getElementById("combination1");
        var strUser = e.options[e.selectedIndex].text;
        var YAxisSelectedItem = '';
        var flag = true;
        $('#combination3 li').each(function () {

          var selectedstring = $(this).next('li').find('input').prop('checked');
          if (selectedstring) {
              if (flag) {
                  var newY = $(this).next('li')[0].innerText;
                // if (!newY.substring(-1).match(/[_\W]/))
                // {
                //   console.log("workin");
                // }
                //   if(newY.indexOf(/[@]+$/) != -1)
                //   {
                //     console.log("run");
                //   }
                var last=newY.charAt(newY.length-2);
                console.log(last);
                // if (last=='') {
                // }
                var match = /\r|\n/.exec(last);
                if (match) {
                  YAxisSelectedItem=newY.substring(0,newY.length-2);
                }
                else {
                  YAxisSelectedItem=newY.substring(0,newY.length-1);
                }
                // if( /[^a-zA-Z0-9]/.test( TCode ) ) {
                //   alert('Input is not alphanumeric');
                //   return false;
                // }
                  // var colorID=YAxisSelectedItem.substring(0, YAxisSelectedItem.length-1);
                  // console.log(document.getElementById(colorID).value);
                  console.log(YAxisSelectedItem);
                  var c = Color(document.getElementById(YAxisSelectedItem).value);
                  color_Array=[c.toString()];
                  flag = false;
                  console.log(c);
              }
              else {
                  var newY=$(this).next('li')[0].innerText;
                  var last=newY.charAt(newY.length-2);
                  console.log(last);
                  // if (last=='') {
                  // }
                  var match = /\r|\n/.exec(last);
                  if (match) {
                    var newY2=newY.substring(0,newY.length-2);
                  }
                  else {
                    var newY2=newY.substring(0,newY.length-1);
                  }
                  // var newY2=newY.substring(0,newY.length-2);
                  console.log(newY2);
                  YAxisSelectedItem = YAxisSelectedItem+","+newY2;
                  // console.log(YAxisSelectedItem);
                  var c = Color(document.getElementById(newY2).value);
                  color_Array.push(c.toString());
                  console.log(YAxisSelectedItem);
              }
          }


        });


        var x = headArray.indexOf(strUser);
        var Zaxis = document.getElementById("combination2");
        var ZaxisValue = Zaxis.options[Zaxis.selectedIndex].text;
        var zindex = headArray.indexOf(ZaxisValue);

        var filterdata = [];
        var tempdata = [];

        var Reportcollen = 0;
        for (var i = 0; i < mystack.length; i++) {

            var column = [];

            column.push(mystack[i][x]);
            var str_array = YAxisSelectedItem.split(',');

            for (var iarr = 0; iarr < str_array.length; iarr++) {
                var y = headArray.indexOf(str_array[iarr]);
                column.push(mystack[i][y]);


            }
            column.push(mystack[i][zindex]);
            filterdata.push(column);
        }

        Reportcollen += str_array.length;
        BindChart(ChartName, ChartTitle, filterdata, Reportcollen,color_Array);

    }


    else if (ChartName == "Scatter chart") {
        var e = document.getElementById("3dim1");
        var strUser = e.options[e.selectedIndex].text;
        var e1 = document.getElementById("3dim2");
        var strUser1 = e1.options[e1.selectedIndex].text;
        var e1 = document.getElementById("3dim3");
        var strUser2 = e1.options[e1.selectedIndex].text;
        var x = headArray.indexOf(strUser);
        var y = headArray.indexOf(strUser1);
        var z = headArray.indexOf(strUser2);
        var filterdata = [];
        var tempdata = [];

        for (var i = 0; i < mystack.length; i++) {
            var column = [];
            console.log(mystack);
            column.push(mystack[i][x]);
            column.push(mystack[i][y]);
            column.push(mystack[i][z]);
            filterdata.push(column);
        }

        var ChartTitle = document.getElementById("title2").value;
        BindChart(ChartName, ChartTitle, filterdata, 0);


    }


        //---------------------------------------------STACKED CHART XY Y
    else if (ChartName == "Stacked chart") {


        var e = document.getElementById("X2Y1");
        var strUser = e.options[e.selectedIndex].text;
        var YAxisSelectedItem = '';
        var flag = true;
        var color_Array=['blue'];
        $('#X2YN li').each(function () {
            // debugger;
            var selectedstring = $(this).next('li').find('input').prop('checked');
            if (selectedstring) {
                if (flag) {
                    var newY = $(this).next('li')[0].innerText;
                  // if (!newY.substring(-1).match(/[_\W]/))
                  // {
                  //   console.log("workin");
                  // }
                  //   if(newY.indexOf(/[@]+$/) != -1)
                  //   {
                  //     console.log("run");
                  //   }
                  var last=newY.charAt(newY.length-2);
                  console.log(last);
                  // if (last=='') {
                  // }
                  var match = /\r|\n/.exec(last);
                  if (match) {
                    YAxisSelectedItem=newY.substring(0,newY.length-2);
                  }
                  else {
                    YAxisSelectedItem=newY.substring(0,newY.length-1);
                  }
                  // if( /[^a-zA-Z0-9]/.test( TCode ) ) {
                  //   alert('Input is not alphanumeric');
                  //   return false;
                  // }
                    // var colorID=YAxisSelectedItem.substring(0, YAxisSelectedItem.length-1);
                    // console.log(document.getElementById(colorID).value);
                    console.log(YAxisSelectedItem);
                    var c = Color(document.getElementById(YAxisSelectedItem).value);
                    color_Array=[c.toString()];
                    flag = false;
                    console.log(c);
                }
                else {
                    var newY=$(this).next('li')[0].innerText;
                    var last=newY.charAt(newY.length-2);
                    console.log(last);
                    // if (last=='') {
                    // }
                    var match = /\r|\n/.exec(last);
                    if (match) {
                      var newY2=newY.substring(0,newY.length-2);
                    }
                    else {
                      var newY2=newY.substring(0,newY.length-1);
                    }
                    // var newY2=newY.substring(0,newY.length-2);
                    console.log(newY2);
                    YAxisSelectedItem = YAxisSelectedItem+","+newY2;
                    // console.log(YAxisSelectedItem);
                    var c = Color(document.getElementById(newY2).value);
                    color_Array.push(c.toString());
                    console.log(YAxisSelectedItem);
                }
            }

        });

        var e1 = document.getElementById("2dim_dropdown2");
        var strUser1 = e1.options[e1.selectedIndex].text;
        var x = headArray.indexOf(strUser);

        var filterdata = [];
        var tempdata = [];
        console.log(x);
        for (var i = 0; i < mystack.length; i++) {
            // debugger;
            var column = [];
            // console.log(mystack);
            column.push(mystack[i][x]);
            var str_array = YAxisSelectedItem.split(',');
            console.log(str_array);
            for (var iarr = 0; iarr < str_array.length; iarr++) {
                var y = headArray.indexOf(str_array[iarr]);
                column.push(mystack[i][y]);


            }
            filterdata.push(column);
        }

        var ChartTitle = document.getElementById("title1").value;

        BindChart(ChartName, ChartTitle, filterdata, 0,color_Array);


    }


        //----------------------------------------------Area GRAPH X Y Y
    else if (ChartName == "Area chart") {




        var e = document.getElementById("X2Y1");
        var strUser = e.options[e.selectedIndex].text;
        var YAxisSelectedItem = '';
        var flag = true;
        var color_Array=['blue'];
        $('#X2YN li').each(function () {
            // debugger;
            var selectedstring = $(this).next('li').find('input').prop('checked');
            if (selectedstring) {
                if (flag) {
                    var newY = $(this).next('li')[0].innerText;
                  // if (!newY.substring(-1).match(/[_\W]/))
                  // {
                  //   console.log("workin");
                  // }
                  //   if(newY.indexOf(/[@]+$/) != -1)
                  //   {
                  //     console.log("run");
                  //   }
                  var last=newY.charAt(newY.length-2);
                  console.log(last);
                  // if (last=='') {
                  // }
                  var match = /\r|\n/.exec(last);
                  if (match) {
                    YAxisSelectedItem=newY.substring(0,newY.length-2);
                  }
                  else {
                    YAxisSelectedItem=newY.substring(0,newY.length-1);
                  }
                  // if( /[^a-zA-Z0-9]/.test( TCode ) ) {
                  //   alert('Input is not alphanumeric');
                  //   return false;
                  // }
                    // var colorID=YAxisSelectedItem.substring(0, YAxisSelectedItem.length-1);
                    // console.log(document.getElementById(colorID).value);
                    console.log(YAxisSelectedItem);
                    var c = Color(document.getElementById(YAxisSelectedItem).value);
                    color_Array=[c.toString()];
                    flag = false;
                    console.log(c);
                }
                else {
                    var newY=$(this).next('li')[0].innerText;
                    var last=newY.charAt(newY.length-2);
                    console.log(last);
                    // if (last=='') {
                    // }
                    var match = /\r|\n/.exec(last);
                    if (match) {
                      var newY2=newY.substring(0,newY.length-2);
                    }
                    else {
                      var newY2=newY.substring(0,newY.length-1);
                    }
                    // var newY2=newY.substring(0,newY.length-2);
                    console.log(newY2);
                    YAxisSelectedItem = YAxisSelectedItem+","+newY2;
                    // console.log(YAxisSelectedItem);
                    var c = Color(document.getElementById(newY2).value);
                    color_Array.push(c.toString());
                    console.log(YAxisSelectedItem);
                }
            }

        });

        var e1 = document.getElementById("2dim_dropdown2");
        var strUser1 = e1.options[e1.selectedIndex].text;
        var x = headArray.indexOf(strUser);

        var filterdata = [];
        var tempdata = [];
        console.log(x);
        for (var i = 0; i < mystack.length; i++) {
            // debugger;
            var column = [];
            // console.log(mystack);
            column.push(mystack[i][x]);
            var str_array = YAxisSelectedItem.split(',');

            for (var iarr = 0; iarr < str_array.length; iarr++) {
                var y = headArray.indexOf(str_array[iarr]);
                column.push(mystack[i][y]);


            }
            filterdata.push(column);
        }

        var ChartTitle = document.getElementById("title").value;
        BindChart(ChartName, ChartTitle, filterdata, 0,color_Array);

    }



        //--------------------------------------------COLUMN CHART
    else if (ChartName == "Column Chart") {
        var e = document.getElementById("2dim_dropdown1");
        var strUser = e.options[e.selectedIndex].text;
        var e1 = document.getElementById("2dim_dropdown2");
        var strUser1 = e1.options[e1.selectedIndex].text;
        var x = headArray.indexOf(strUser);
        var y = headArray.indexOf(strUser1);
        var filterdata = [];
        var tempdata = [];

        for (var i = 0; i < mystack.length; i++) {
            var column = [];
            console.log(mystack);
            column.push(mystack[i][x]);
            column.push(mystack[i][y]);
            filterdata.push(column);
        }

        var ChartTitle = document.getElementById("title").value;
        BindChart(ChartName, ChartTitle, filterdata, 0);


    }

    else if (ChartName == "Donut Chart") {
        var e = document.getElementById("2dim_dropdown1");
        var strUser = e.options[e.selectedIndex].text;
        var e1 = document.getElementById("2dim_dropdown2");
        var strUser1 = e1.options[e1.selectedIndex].text;
        var x = headArray.indexOf(strUser);
        var y = headArray.indexOf(strUser1);
        var filterdata = [];
        var tempdata = [];
        console.log(x);
        for (var i = 0; i < mystack.length; i++) {
            var column = [];
            console.log(mystack);
            column.push(mystack[i][x]);
            column.push(mystack[i][y]);
            filterdata.push(column);
        }


        var ChartTitle = document.getElementById("title").value;

        BindChart(ChartName, ChartTitle, filterdata, 0);

    }


        //--------------------------------------------------PIE CHART
    else if (ChartName == "Pie Chart") {

        var e = document.getElementById("2dim_dropdown1");
        var strUser = e.options[e.selectedIndex].text;
        var e1 = document.getElementById("2dim_dropdown2");
        var strUser1 = e1.options[e1.selectedIndex].text;
        var x = headArray.indexOf(strUser);
        var y = headArray.indexOf(strUser1);
        var filterdata = [];
        var tempdata = [];

        for (var i = 0; i < mystack.length; i++) {
            // debugger;
            var column = [];

            column.push(mystack[i][x]);
            column.push(mystack[i][y]);
            filterdata.push(column);
        }

        var ChartTitle = document.getElementById("title").value;

        BindChart(ChartName, ChartTitle, filterdata, 0);

    }

        //-------------------------------------------------LINE CHART xy y
    else if (ChartName == "Line Chart") {

        var e = document.getElementById("X2Y1");
        var strUser = e.options[e.selectedIndex].text;
        var YAxisSelectedItem = '';
        var flag = true;
        var color_Array=['blue'];
        $('#X2YN li').each(function () {
            // debugger;
            var selectedstring = $(this).next('li').find('input').prop('checked');
            if (selectedstring) {
                if (flag) {
                    var newY = $(this).next('li')[0].innerText;
                  // if (!newY.substring(-1).match(/[_\W]/))
                  // {
                  //   console.log("workin");
                  // }
                  //   if(newY.indexOf(/[@]+$/) != -1)
                  //   {
                  //     console.log("run");
                  //   }
                  var last=newY.charAt(newY.length-2);
                  console.log(last);
                  // if (last=='') {
                  // }
                  var match = /\r|\n/.exec(last);
                  if (match) {
                    YAxisSelectedItem=newY.substring(0,newY.length-2);
                  }
                  else {
                    YAxisSelectedItem=newY.substring(0,newY.length-1);
                  }
                  // if( /[^a-zA-Z0-9]/.test( TCode ) ) {
                  //   alert('Input is not alphanumeric');
                  //   return false;
                  // }
                    // var colorID=YAxisSelectedItem.substring(0, YAxisSelectedItem.length-1);
                    // console.log(document.getElementById(colorID).value);
                    console.log(YAxisSelectedItem);
                    var c = Color(document.getElementById(YAxisSelectedItem).value);
                    color_Array=[c.toString()];
                    flag = false;
                    console.log(c);
                }
                else {
                    var newY=$(this).next('li')[0].innerText;
                    var last=newY.charAt(newY.length-2);
                    console.log(last);
                    // if (last=='') {
                    // }
                    var match = /\r|\n/.exec(last);
                    if (match) {
                      var newY2=newY.substring(0,newY.length-2);
                    }
                    else {
                      var newY2=newY.substring(0,newY.length-1);
                    }
                    // var newY2=newY.substring(0,newY.length-2);
                    console.log(newY2);
                    YAxisSelectedItem = YAxisSelectedItem+","+newY2;
                    // console.log(YAxisSelectedItem);
                    var c = Color(document.getElementById(newY2).value);
                    color_Array.push(c.toString());
                    console.log(YAxisSelectedItem);
                }
            }

        });

        var e1 = document.getElementById("2dim_dropdown2");
        var strUser1 = e1.options[e1.selectedIndex].text;
        var x = headArray.indexOf(strUser);

        var filterdata = [];
        var tempdata = [];
        console.log(x);
        for (var i = 0; i < mystack.length; i++) {
            // debugger;
            var column = [];
            // console.log(mystack);
            column.push(mystack[i][x]);
            var str_array = YAxisSelectedItem.split(',');

            for (var iarr = 0; iarr < str_array.length; iarr++) {
                var y = headArray.indexOf(str_array[iarr]);
                column.push(mystack[i][y]);


            }
            filterdata.push(column);
        }



        var ChartTitle = document.getElementById("title").value;
        BindChart(ChartName, ChartTitle, filterdata, 0,color_Array);

    }





    return false;



}
//----to convert json into html table

// var myList;
var myList = [
  { "Month": "2004/05", "Bolivia": 165, "Ecuador": 938, "Madagascar": 522, "Papua New Guinea": 998, "Rwanda": 450, "Average": 614.6 },
{ "Month": "2004/05", "Bolivia": 135, "Ecuador": 1120, "Madagascar": 599, "Papua New Guinea": 1268, "Rwanda": 288, "Average": 682 },
{ "Month": "2004/05", "Bolivia": 157, "Ecuador": 1167, "Madagascar": 587, "Papua New Guinea": 807, "Rwanda": 397, "Average": 623 },
{ "Month": "2004/05", "Bolivia": 139, "Ecuador": 1110, "Madagascar": 691, "Papua New Guinea": 968, "Rwanda": 215, "Average": 609.4 }
];


var mystack = [];
var headArray = [];

// var data=JSON.parse(myList);
// console.log(data);

// Builds the HTML Table out of myList.
function buildHtmlTable(selector) {
    //   debugger;
    // $.ajax({
    //     contentType: 'application/json; charset=utf-8',
    //     type: "GET",
    //     url: "../Reports/ShowJsonReports",
    //     //  dataType: "json",
    //     // data: JSON.stringify(ElementDatas),
    //     cache: false,
    //     async: false,
    //       // error: function (lstReport) {
    //       //     //  debugger
    //       //     alert("Request: " + XMLHttpRequest.toString() + "\n\nStatus: " + textStatus + "\n\nError: " + errorThrown);
    //       // },
    //     success: function (lstReport) {
    //         // debugger
    //         myList = lstReport.lstReport;
    //         // alert('test');
    //         // buildHtmlTable('#DataTable');
    //     }
    // });
    var columns = addAllColumnHeaders(myList, selector);
    var flagcolchk = false;
    for (var i = 0; i < myList.length; i++) {
        flagcolchk = true;
        var row$ = $('<tr/>');
        var temp = [];
        // alert(columns.length);
        for (var colIndex = 0; colIndex < columns.length; colIndex++) {
            var cellValue = myList[i][columns[colIndex]];
            console.log(cellValue);
            if (cellValue == null) cellValue = "";
            row$.append($('<td/>').html(cellValue));
            temp.push(cellValue);
            // alert(JSON.stringify(temp));
        }
        // alert("first end");
        mystack.push(temp);
        $(selector).append(row$);
    }
    if (flagcolchk) {
        $('#ChartArea').show();
        viewchart1();
    }

    //  alert(JSON.stringify(mystack));
}

// Adds a header row to the table and returns the set of columns.
// Need to do union of keys from all records as some records may not contain
// all records.
function addAllColumnHeaders(myList, selector) {
    // debugger;
    var columnSet = [];
    var headerTr$ = $('<tr/>');
    var temp = [];
    for (var i = 0; i < myList.length; i++) {
        var rowHash = myList[i];
        for (var key in rowHash) {
            if ($.inArray(key.trim(), columnSet) == -1) {
                columnSet.push(key.trim());
                headerTr$.append($('<th/>').html(key.trim()));

            }
        }
    }
    // debugger;
    headArray = columnSet;
    // alert(JSON.stringify(headArray));
    mystack.push(columnSet);
    headerTr$.addClass('menuaddcontainer');
    $(selector).append(headerTr$);

    return columnSet;

}



function BindChart(ChartType, ChartTitle, Chartdata, ZColumn,colors_Arr) {
    //debugger;
    switch (ChartType) {
        case 'Line-Bar chart':
            LineBarChart(Chartdata, ChartTitle, ZColumn,colors_Arr);
            break;
        case 'Bar-Line chart':
            BarLineChart(Chartdata, ChartTitle, ZColumn,colors_Arr);
            break;
        case 'Area-Bar chart':
            AreaBarChart(Chartdata, ChartTitle, ZColumn,colors_Arr);
            break;
        case 'Bar-Area chart':
            BarAreaChart(Chartdata, ChartTitle, ZColumn,colors_Arr);
            break;
        case 'Area-Line chart':
            AreaLineChart(Chartdata, ChartTitle, ZColumn,colors_Arr);
            break;
        case 'Line-Area chart':
            LineAreaChart(Chartdata, ChartTitle, ZColumn,colors_Arr);
            break;
        case 'Scatter chart':
            ScatterChart(Chartdata, ChartTitle);
            break;
        case 'Stacked chart':
            StackedChart(Chartdata, ChartTitle,colors_Arr);
            break;
        case 'Area chart':
            AreaChart(Chartdata, ChartTitle,colors_Arr);
            break;
        case 'Column Chart':
            ColumnChart(Chartdata, ChartTitle);
            break;
        case 'Donut Chart':
            DonutChart(Chartdata, ChartTitle);
            break;
        case "Pie Chart":

            PieChart(Chartdata, ChartTitle);
            break;
        case 'Line Chart':
            LineChart(Chartdata, ChartTitle,colors_Arr);
            break;
        default:

            break;
    }
}

function LineBarChart(Chartdata, ChartTitle, ZColumn,colors_Array) {

    $('#DrawChart').empty();
    if (tempcol!='') {
      colors_Array.push(tempcol);
    }
    document.getElementById('DrawChart').style.display = 'block';
    google.charts.load('current', { 'packages': ['corechart'] });
    google.charts.setOnLoadCallback(drawVisualization);
    function drawVisualization() {

        var data = google.visualization.arrayToDataTable(Chartdata);
        var options = {
            title: ChartTitle,
            'colors' : colors_Array,
            //vAxis: { title: 'Cups' },
            //hAxis: { title: 'Month' },
            seriesType: 'line',

            series: ""
        };

        myObj = {};
        myObj[ZColumn] = { type: "bars" };
        options.series = myObj;

        var chart = new google.visualization.ComboChart(document.getElementById('DrawChart'));
        chart.draw(data, options);
        $('#png').empty();
        //$('#chart_Image').empty();

        document.getElementById('png').innerHTML = '<a  href="' + chart.getImageURI() + '" download>Download</a>';
    }

}
function BarLineChart(Chartdata, ChartTitle, ZColumn,colors_Array) {
    console.log(ChartName);
    $('#DrawChart').empty();
    if (tempcol!='') {
      colors_Array.push(tempcol);
    }
    document.getElementById('DrawChart').style.display = 'block';
    google.charts.load('current', { 'packages': ['corechart'] });
    google.charts.setOnLoadCallback(drawVisualization);

    function drawVisualization() {

        var data = google.visualization.arrayToDataTable(Chartdata);
        var options = {
            title: ChartTitle,
            'colors' : colors_Array,
            // vAxis: { title: 'Cups' },
            //  hAxis: { title: 'Month' },
            seriesType: 'bars',
            series: ""
        };

        myObj = {};
        myObj[ZColumn] = { type: "line" };
        options.series = myObj;

        var chart = new google.visualization.ComboChart(document.getElementById('DrawChart'));
        chart.draw(data, options);
        $('#png').empty();
        //$('#chart_Image').empty();
        document.getElementById('png').innerHTML = '<a  href="' + chart.getImageURI() + '" download>Download</a>';
    }
}
function AreaBarChart(Chartdata, ChartTitle, ZColumn,colors_Array) {
    console.log(ChartName);
    $('#DrawChart').empty();
    if (tempcol!='') {
      colors_Array.push(tempcol);
    }
    document.getElementById('DrawChart').style.display = 'block';
    google.charts.load('current', { 'packages': ['corechart'] });
    google.charts.setOnLoadCallback(drawVisualization);

    function drawVisualization() {


        var data = google.visualization.arrayToDataTable(Chartdata);
        var options = {
            title: ChartTitle,
            'colors' : colors_Array,
            // vAxis: { title: 'Cups' },
            // hAxis: { title: 'Month' },
            seriesType: 'area',
            series: ""
        };

        myObj = {};
        myObj[ZColumn] = { type: "bars" };
        options.series = myObj;

        var chart = new google.visualization.ComboChart(document.getElementById('DrawChart'));
        chart.draw(data, options);
        $('#png').empty();

        document.getElementById('png').innerHTML = '<a  href="' + chart.getImageURI() + '" download>Download</a>';
    }
}
function BarAreaChart(Chartdata, ChartTitle, ZColumn,colors_Array) {
    $('#DrawChart').empty();
    if (tempcol!='') {
      colors_Array.push(tempcol);
    }
    document.getElementById('DrawChart').style.display = 'block';
    google.charts.load('current', { 'packages': ['corechart'] });
    google.charts.setOnLoadCallback(drawVisualization);

    function drawVisualization() {

        var data = google.visualization.arrayToDataTable(Chartdata);
        var options = {
            title: ChartTitle,
            'colors' : colors_Array,
            //  vAxis: { title: 'Cups' },
            //  hAxis: { title: 'Month' },
            seriesType: 'bars',
            series: ""
        };

        myObj = {};
        myObj[ZColumn] = { type: "area" };
        options.series = myObj;

        var chart = new google.visualization.ComboChart(document.getElementById('DrawChart'));
        chart.draw(data, options);
        $('#png').empty();

        document.getElementById('png').innerHTML = '<a  href="' + chart.getImageURI() + '" download>Download</a>';
    }
}
function AreaLineChart(Chartdata, ChartTitle, ZColumn,colors_Array) {
    $('#DrawChart').empty();
    if (tempcol!='') {
      colors_Array.push(tempcol);
    }
    document.getElementById('DrawChart').style.display = 'block';
    google.charts.load('current', { 'packages': ['corechart'] });
    google.charts.setOnLoadCallback(drawVisualization);

    function drawVisualization() {



        var data = google.visualization.arrayToDataTable(Chartdata);

        var options = {
            title: ChartTitle,
            'colors' : colors_Array,
            // vAxis: { title: strUser1 },
            //  hAxis: { title: strUser },
            seriesType: 'area',
            series: ""
        };

        myObj = {};
        myObj[ZColumn] = { type: "line" };
        options.series = myObj;

        var chart = new google.visualization.ComboChart(document.getElementById('DrawChart'));
        chart.draw(data, options);
        $('#png').empty();

        document.getElementById('png').innerHTML = '<a  href="' + chart.getImageURI() + '" download>Download</a>';
    }
}
function LineAreaChart(Chartdata, ChartTitle, ZColumn,colors_Array) {
    $('#DrawChart').empty();
    if (tempcol!='') {
      colors_Array.push(tempcol);
    }
    document.getElementById('DrawChart').style.display = 'block';
    google.charts.load('current', { 'packages': ['corechart'] });
    google.charts.setOnLoadCallback(drawVisualization);

    function drawVisualization() {


        var data = google.visualization.arrayToDataTable(Chartdata);

        var options = {
            title: ChartTitle,
            'colors' : colors_Array,
            // vAxis: { title: 'Cups' },
            // hAxis: { title: 'Month' },
            seriesType: 'line',
            series: ""
        };

        myObj = {};
        myObj[ZColumn] = { type: "area" };
        options.series = myObj;

        var chart = new google.visualization.ComboChart(document.getElementById('DrawChart'));
        chart.draw(data, options);
        $('#png').empty();

        document.getElementById('png').innerHTML = '<a  href="' + chart.getImageURI() + '" download>Download</a>';
    }
}
function ScatterChart(Chartdata, ChartTitle) {


    $('#DrawChart').empty();

    document.getElementById('DrawChart').style.display = 'block';

    google.charts.load('current', { 'packages': ['scatter'] });
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {

        var data = google.visualization.arrayToDataTable(Chartdata);


        var options = {
            width: 800,
            height: 500,
            'colors' : mycolor,
            chart: {
                title: ChartTitle,

            }//,
            //   hAxis: { title: strUser },
            // vAxis: { title: strUser1 }
        };

        var chart = new google.charts.Scatter(document.getElementById('DrawChart'));

        chart.draw(data, options);
        $('#google-visualization-errors-0').hide()
        $('#png').empty();

        document.getElementById('png').innerHTML = '<a  href="' + chart.getImageURI() + '" download>Download</a>';
    }

}
function StackedChart(Chartdata, ChartTitle,colors_Array) {
    $('#DrawChart').empty();
    console.log(Chartdata);

    document.getElementById('DrawChart').style.display = 'block';
    google.charts.load("current", { packages: ['corechart'] });
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {


        var Columndata = google.visualization.arrayToDataTable(Chartdata);


        var view = new google.visualization.DataView(Columndata);


        var options = {
            title: ChartTitle,
            width: 400,
            height: 300,
            hAxis: { title: '1' },
            vAxis: { title: '2' },
            legend: { position: 'top', maxLines: 3 },
            'colors' : colors_Array,
            bar: { groupWidth: '50%' },
            isStacked: true,
        };
        var chart = new google.visualization.ColumnChart(document.getElementById("DrawChart"));

        chart.draw(view, options);
        $('#png').empty();

        document.getElementById('png').innerHTML = '<a  href="' + chart.getImageURI() + '" download>Download</a>';

    }
}
function AreaChart(Chartdata, ChartTitle,colors_Array) {
    $('#DrawChart').empty();

    document.getElementById('DrawChart').style.display = 'block';
    google.charts.load('current', { 'packages': ['corechart'] });
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {


        var options = {
            title: ChartTitle,
            'colors' : colors_Array,
            //hAxis: { title: strUser, titleTextStyle: { color: '#333' } },
            //vAxis: { title: strUser1, minValue: 0 }
        };
        var AreaData = google.visualization.arrayToDataTable(Chartdata);

        var chart = new google.visualization.AreaChart(document.getElementById('DrawChart'));
        chart.draw(AreaData, options);
        $('#png').empty();

        document.getElementById('png').innerHTML = '<a  href="' + chart.getImageURI() + '" download>Download</a>';

    }
}
function ColumnChart(Chartdata, ChartTitle) {

    $('#DrawChart').empty();
    document.getElementById('DrawChart').style.display = 'block';

    google.charts.load("current", { packages: ['corechart'] });
    google.charts.setOnLoadCallback(drawColChart);

    function drawColChart() {
       // debugger;
        var options = {
            width: 300,
            // legend: { position: 'none' },
            chart: {
                title: ChartTitle,

            },
            // 'colors' : ["#194D86"],

            'colors' : mycolor,

           // vAxis: { title: strUser1 },
            //axes: {
            //    x: {
            //        0: { label: strUser } // Top x-axis.
            //    }
            //},
            bar: { groupWidth: "60%" }
        };
        var Columndata = google.visualization.arrayToDataTable(Chartdata);
        var chart = new google.visualization.ColumnChart(document.getElementById("DrawChart"));
        google.visualization.events.addListener(chart, 'select', selectHandler);

        chart.draw(Columndata, options);

        $('#png').empty();

        document.getElementById('png').innerHTML = '<a  href="' + chart.getImageURI() + '" download>Download</a>';

        // google.visualization.events.addListener(chart, 'select', function() {
        // alert("google calling");
        // });

        function selectHandler() {
          var selectedItem = chart.getSelection()[0];
          if (selectedItem) {
            var topping = Columndata.getValue(selectedItem.row, 0);
            alert('The user selected ' + topping);
          }
        }

    };
}
function DonutChart(Chartdata, ChartTitle) {

    $('#DrawChart').empty();

    document.getElementById('DrawChart').style.display = 'block';

    google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {

        var options = {
            //  hAxis: { title: strUser },
            // vAxis: { title: strUser1 },
            title: ChartTitle,
            pieHole: 0.4,
        };
        var data = google.visualization.arrayToDataTable(Chartdata);

        var chart = new google.visualization.PieChart(document.getElementById('DrawChart'));
        chart.draw(data, options);
        $('#png').empty();

        document.getElementById('png').innerHTML = '<a  href="' + chart.getImageURI() + '" download>Download</a>';


    }
}
function PieChart(Chartdata, ChartTitle) {
  console.log(Chartdata.length);
  var mycolr=['red','blue','green','grey','cyan','brown','orange','purple','Aliceblue','Aqua'];
  var color_Array=[];
  var index=0;
  for (var i = 0; i < Chartdata.length-1; i++) {
    // index =i;
    // console.log(index);
    color_Array[i]=mycolr[index];
    index++;
    if(index>9)
      index=0;
  }
// console.log(color_Array);
    $('#DrawChart').empty();

    document.getElementById('DrawChart').style.display = 'block';
    google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {


        var Pieoptions = {
            title: ChartTitle,
            is3D: true,
            'colors':color_Array,
            //  slices: {3: {color: '#006EFF'}},
              // colors:[],
        };


        var chart = new google.visualization.PieChart(document.getElementById('DrawChart'));

        var Columndata = google.visualization.arrayToDataTable(Chartdata);

        var view = new google.visualization.DataView(Columndata);
        view.setColumns([0, 1,
                         {
                             calc: "stringify",
                             sourceColumn: 1,
                             type: "string",
                             role: "annotation"
                         }]);
        google.visualization.events.addListener(chart, 'click', selectHandler);

        chart.draw(view, Pieoptions);

        $('#png').empty();
        document.getElementById('png').innerHTML = '<a  href="' + chart.getImageURI() + '" download>Download</a>';
        function selectHandler() {
          console.log("enter");
          var colnew='';
          var selectedItem = chart.getSelection()[0];
          if (selectedItem) {
            var topping = Columndata.getValue(selectedItem.row, 0);
            console.log(selectedItem);
            // $("#testi").spectrum({
            // flat: true,
            // showInput: true
            // });
            $("#testi").spectrum({
              flat: true,
              showInput: true,
                // move: function(tinycolor) { },
                // show: function(tinycolor) { },
                change: function(tinycolor) {
                  // document.getElementById("2dim_dropdown2").style.color= tinycolor.toHexString();
                  //  alert(tinycolor.toHexString());
                  // console.log(tinycolor);
                   colnew = tinycolor.toHexString();
                  alert(Pieoptions);
                  // google.visualization.events.addListener(chart, 'click', selectHandler);
                  console.log(Pieoptions);

                   Pieoptions.colors[selectedItem.row]=colnew;
                  //  Pieoptions.slices[selectedItem.row].color=colnew;
                //   Pieoptions={
                //   slices: {3: {color: colnew}},
                // }

                   chart.draw(view, Pieoptions);
                   $("#testi").spectrum({
                     flat: false,
                     showInput: false,
                   });

                 }
                // beforeShow: function(tinycolor) { },
            });
          }
        }


    }
}
function LineChart(Chartdata, ChartTitle,colors_Array) {

    $('#DrawChart').empty();

    document.getElementById('DrawChart').style.display = 'block';
    google.charts.load('current', { 'packages': ['corechart'] });
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {



        var data = google.visualization.arrayToDataTable(Chartdata);

        var options = {
            //hAxis: { title: strUser },
            //vAxis: { title: strUser1 },
            title: ChartTitle,
            'colors' : colors_Array,
            curveType: 'function',
            legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('DrawChart'));

        chart.draw(data, options);
        $('#png').empty();

        document.getElementById('png').innerHTML = '<a  href="' + chart.getImageURI() + '" download>Download</a>';

    }
}

mycolor=["black"];
colorflag=0;
var tempcol='';
function chartcolor(color)
{
    mycolor=[color];
    // colorflag=1;

}
function chartcolor2(color)
{
    mycolor[0]=color;
    // colorflag=1;

}
function chartcolor3(color)
{
    mycolor[1]=color;
    // colorflag=1;

}
function chartcolor4(color)
{
    tempcol=color;
    // colorflag=1;

}

google.visualization.events.addListener(orgchart, 'select', function() {
alert("google calling");
});
